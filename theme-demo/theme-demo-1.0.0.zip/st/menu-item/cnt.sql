INSERT INTO pageitem ("name","visible","area","sortid","subtemplate","crdate") VALUES ("Info","true","Menu",0,"app.contemple.demo.Menu-Item","now");
INSERT INTO ex_app_contemple_demo_menuitem ("name","label","link") VALUES ("Info","INFO","index.html");

INSERT INTO pageitem ("name","visible","area","sortid","subtemplate","crdate") VALUES ("Kontakt","true","Menu",1,"app.contemple.demo.Menu-Item","now");
INSERT INTO ex_app_contemple_demo_menuitem ("name","label","link") VALUES ("Kontakt","KONTAKT","contact.html");
