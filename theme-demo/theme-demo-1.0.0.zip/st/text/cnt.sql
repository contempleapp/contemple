
INSERT INTO pageitem ("name","visible","area","sortid","subtemplate","crdate") VALUES ("Blog-Title","true","Home",1,"app.contemple.demo.Text","now");
INSERT INTO ex_app_contemple_demo_text ("name","style","value") VALUES("Blog-Title","font-light size-xl","# Blog #br#");

INSERT INTO pageitem ("name","visible","area","sortid","subtemplate","crdate") VALUES ("Blog-1","true","Home",2,"app.contemple.demo.Text","now");
INSERT INTO ex_app_contemple_demo_text ("name","style","value") VALUES("Blog-1","size-m","4/2019#BR### Contemple Demo Website#BR##BR#For demonstration purpose, the Demo Website is very simple.#BR##BR#It allows to create new Menu Items, Pages, and add new Text Items to the page content.#BR##BR#Under Settings, the Logo, Background and Flares Images can be changed, along with some other basic settings.#BR##BR#To edit and view the **Source Code** of the **Theme**, select Developer/Edit Template from the main menu.#BR#");

INSERT INTO pageitem ("name","visible","area","sortid","subtemplate","crdate") VALUES ("Contact-Title","true","Contact",1,"app.contemple.demo.Text","now");
INSERT INTO ex_app_contemple_demo_text ("name","style","value") VALUES("Contact-Title","font-light size-xl","# Contact #br#");
